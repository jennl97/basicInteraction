//
//  ViewController.swift
//  basicInteraction
//
//  Created by Jenn Hott on 1/30/17.
//  Copyright © 2017 Jenn Hott. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var statusLabel: UILabel!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        let title = sender.title(for: .selected)!
        
        let text = "\(title) button pressed"
        statusLabel.text = text
        
    }

}

